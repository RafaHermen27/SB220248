<?php
// Database Configuration
$host = "localhost";  // Change this if using a remote server
$dbname = "crowdfunding_db"; // Change this to your actual database name
$username = "root";  // Change this if using a different user
$password = "";  // Change this if your database has a password

try {
    // Create a new PDO connection
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    
    // Set PDO to throw exceptions on error
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    // Display error message if connection fails
    die("Database connection failed: " . $e->getMessage());
}
?>
