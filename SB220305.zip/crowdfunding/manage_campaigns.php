<?php
session_start();
include 'config.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

// Handle Approve and Delete Actions
if (isset($_GET['approve'])) {
    $campaign_id = intval($_GET['approve']);
    $query = "UPDATE campaigns SET status='approved' WHERE id=$campaign_id";
    mysqli_query($conn, $query);
    header("Location: manage_campaigns.php");
    exit();
}

if (isset($_GET['delete'])) {
    $campaign_id = intval($_GET['delete']);
    $query = "DELETE FROM campaigns WHERE id=$campaign_id";
    mysqli_query($conn, $query);
    header("Location: manage_campaigns.php");
    exit();
}

// Fetch all campaigns
$query = "SELECT * FROM campaigns ORDER BY created_at DESC";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Campaigns - Admin</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand" href="admin_dashboard.php">Crowdfunding Admin</a>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav ms-auto">
            <li class="nav-item"><a class="nav-link" href="admin_dashboard.php">Dashboard</a></li>
                <li class="nav-item"><a class="nav-link" href="manage_campaigns.php">Manage Campaigns</a></li>
                <li class="nav-item"><a class="nav-link" href="users.php">Manage Users</a></li>
                <li class="nav-item"><a class="nav-link" href="transactions1.php">Transactions</a></li>
                
              
                <li class="nav-item"><a class="nav-link" href="index.php">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <h3 class="mb-3">Manage Campaigns</h3>
    <table class="table table-bordered">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Title</th>
                <th>Goal Amount</th>
                <th>Raised</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($campaign = mysqli_fetch_assoc($result)) { ?>
                <tr>
                    <td><?php echo $campaign['id']; ?></td>
                    <td><?php echo $campaign['title']; ?></td>
                    <td>$<?php echo $campaign['goal_amount']; ?></td>
                    <td>$<?php echo $campaign['raised_amount']; ?></td>
                    <td>
                        <span class="badge bg-<?php echo ($campaign['status'] == 'approved') ? 'success' : 'warning'; ?>">
                            <?php echo ucfirst($campaign['status']); ?>
                        </span>
                    </td>
                    <td>
                        <?php if ($campaign['status'] == 'pending') { ?>
                            <a href="manage_campaigns.php?approve=<?php echo $campaign['id']; ?>" class="btn btn-success btn-sm">Approve</a>
                        <?php } ?>
                        <a href="manage_campaigns.php?delete=<?php echo $campaign['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?');">Delete</a>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
