<?php
session_start();
include 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: transactions.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch all transactions (donations) by the user
$transactions_query = "SELECT d.amount, d.message, d.donated_at, c.title, d.status 
                       FROM donations d 
                       JOIN campaigns c ON d.campaign_id = c.id 
                       WHERE d.user_id='$user_id' 
                       ORDER BY d.donated_at DESC";

$transactions_result = mysqli_query($conn, $transactions_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaction History - Crowdfunding</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 50px;
        }
        .card {
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        .navbar {
            background-color: #007bff;
        }
        .navbar-brand, .nav-link {
            color: #fff !important;
        }
        .btn-primary {
            background-color: #28a745;
            border: none;
        }
        table {
            background: #fff;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand" href="index.php">Crowdfunding</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="campaigns.php">Campaigns</a></li>
                <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
                <li class="nav-item"><a class="nav-link" href="profile.php">Profile</a></li>
                <li class="nav-item"><a class="nav-link" href="donate.php">Donate</a></li>
                <li class="nav-item"><a class="nav-link active" href="transactions.php">Transactions</a></li>
                <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<!-- Transaction History -->
<div class="container">
    <h3 class="text-center">Transaction History</h3>

    <div class="card p-4 mt-4">
        <h5>Your Donations</h5>
        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>Campaign</th>
                        <th>Amount (₹)</th>
                        <th>Message</th>
                        <th>Date</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($transaction = mysqli_fetch_assoc($transactions_result)) { ?>
                        <tr>
                            <td><?php echo htmlspecialchars($transaction['title']); ?></td>
                            <td>₹<?php echo number_format($transaction['amount']); ?></td>
                            <td><?php echo nl2br(htmlspecialchars($transaction['message'])); ?></td>
                            <td><?php echo date("F j, Y", strtotime($transaction['donated_at'])); ?></td>
                            <td>
                                <?php if ($transaction['status'] == 'Completed') { ?>
                                    <span class="badge bg-success">Completed</span>
                                <?php } elseif ($transaction['status'] == 'Pending') { ?>
                                    <span class="badge bg-warning text-dark">Pending</span>
                                <?php } else { ?>
                                    <span class="badge bg-danger">Failed</span>
                                <?php } ?>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
