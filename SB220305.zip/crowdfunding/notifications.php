<?php
session_start();
include 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: user_login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Mark all unread notifications as read
if (isset($_POST['mark_all_read'])) {
    $update_query = "UPDATE notifications SET status='read' WHERE user_id='$user_id' AND status='unread'";
    mysqli_query($conn, $update_query);
}

// Fetch Notifications
$notifications_query = "SELECT * FROM notifications WHERE user_id='$user_id' ORDER BY created_at DESC";
$notifications_result = mysqli_query($conn, $notifications_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notifications - Crowdfunding</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 50px;
        }
        .card {
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        .navbar {
            background-color: #007bff;
        }
        .navbar-brand, .nav-link {
            color: #fff !important;
        }
        .btn-primary {
            background-color: #28a745;
            border: none;
        }
        .unread {
            font-weight: bold;
            color: #dc3545;
        }
        .table {
            background: #fff;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand" href="index.php">Crowdfunding</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="campaigns.php">Campaigns</a></li>
                <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
                <li class="nav-item"><a class="nav-link" href="profile.php">Profile</a></li>
                <li class="nav-item"><a class="nav-link" href="donate.php">Donate</a></li>
                <li class="nav-item"><a class="nav-link" href="transactions.php">Transactions</a></li>
                <li class="nav-item"><a class="nav-link" href="withdraw.php">Withdraw</a></li>
                <li class="nav-item"><a class="nav-link active" href="notifications.php">Notifications</a></li>
                <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<!-- Notifications Section -->
<div class="container">
    <h3 class="text-center">Notifications</h3>

    <div class="card p-4 mt-4">
        <h5>Recent Notifications</h5>
        
        <!-- Mark All Read Button -->
        <form method="POST" action="">
            <button type="submit" name="mark_all_read" class="btn btn-primary mb-3">Mark All as Read</button>
        </form>

        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>Message</th>
                        <th>Date</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($notification = mysqli_fetch_assoc($notifications_result)) { ?>
                        <tr class="<?php echo ($notification['status'] == 'unread') ? 'unread' : ''; ?>">
                            <td><?php echo htmlspecialchars($notification['message']); ?></td>
                            <td><?php echo date("F j, Y, g:i A", strtotime($notification['created_at'])); ?></td>
                            <td>
                                <?php if ($notification['status'] == 'unread') { ?>
                                    <span class="badge bg-danger">Unread</span>
                                <?php } else { ?>
                                    <span class="badge bg-success">Read</span>
                                <?php } ?>
                            </td>
                        </tr>
                    <?php } ?>
                    <?php if (mysqli_num_rows($notifications_result) == 0) { ?>
                        <tr><td colspan="3" class="text-center">No notifications yet.</td></tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
