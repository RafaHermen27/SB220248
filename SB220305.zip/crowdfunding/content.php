<?php
session_start();
include 'config.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

// Handle Add or Update Content
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $page_id = $_POST['page_id'];
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $content = mysqli_real_escape_string($conn, $_POST['content']);

    if ($page_id == 0) {
        // Insert New Page
        $query = "INSERT INTO static_pages (title, content) VALUES ('$title', '$content')";
    } else {
        // Update Existing Page
        $query = "UPDATE static_pages SET title='$title', content='$content' WHERE id='$page_id'";
    }
    mysqli_query($conn, $query);
    header("Location: content.php");
}

// Handle Delete
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    mysqli_query($conn, "DELETE FROM static_pages WHERE id='$delete_id'");
    header("Location: content.php");
}

// Fetch Pages
$pages = mysqli_query($conn, "SELECT * FROM static_pages ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Content - Crowdfunding</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
    <style>
        body { background-color: #f8f9fa; }
        .container { margin-top: 50px; }
        .card { padding: 20px; box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1); border-radius: 10px; }
        .navbar { background-color: #007bff; }
        .navbar-brand, .nav-link { color: #fff !important; }
        .table-responsive { max-height: 400px; overflow-y: auto; }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand" href="admin_dashboard.php">Crowdfunding Admin</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
            <li class="nav-item"><a class="nav-link" href="admin_dashboard.php">Dashboard</a></li>
                <li class="nav-item"><a class="nav-link" href="manage_campaigns.php">Manage Campaigns</a></li>
                <li class="nav-item"><a class="nav-link" href="users.php">Manage Users</a></li>
                <li class="nav-item"><a class="nav-link" href="transactions1.php">Transactions</a></li>
                <li class="nav-item"><a class="nav-link" href="categories.php">Categories</a></li>
                <li class="nav-item"><a class="nav-link" href="reports.php">Reports</a></li>
                
                <li class="nav-item"><a class="nav-link" href="index.php">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<!-- Content Management Section -->
<div class="container">
    <h2 class="text-center mb-4">Manage Static Pages</h2>

    <!-- Add/Edit Content Form -->
    <div class="card mb-4">
        <h4 class="card-title text-center">Add / Edit Page</h4>
        <form method="POST">
            <input type="hidden" name="page_id" id="page_id" value="0">
            <div class="mb-3">
                <label class="form-label">Page Title</label>
                <input type="text" class="form-control" name="title" id="title" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Content</label>
                <textarea class="form-control" name="content" id="content" rows="5" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary w-100">Save Page</button>
        </form>
    </div>

    <!-- Pages List -->
    <div class="card">
        <h4 class="card-title text-center">Existing Pages</h4>
        <div class="table-responsive">
            <table class="table table-bordered table-striped">
                <thead class="table-primary">
                    <tr>
                        <th>ID</th>
                        <th>Title</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($pages)) { ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo $row['title']; ?></td>
                        <td>
                            <button class="btn btn-warning btn-sm" onclick="editPage('<?php echo $row['id']; ?>', '<?php echo addslashes($row['title']); ?>', '<?php echo addslashes($row['content']); ?>')">Edit</button>
                            <a href="content.php?delete_id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">Delete</a>
                        </td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    CKEDITOR.replace('content');

    function editPage(id, title, content) {
        document.getElementById('page_id').value = id;
        document.getElementById('title').value = title;
        CKEDITOR.instances['content'].setData(content);
    }
</script>
</body>
</html>
