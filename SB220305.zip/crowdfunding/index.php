<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home - Crowdfunding Platform</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body { background-color:rgb(36, 134, 232); }
        .navbar { background-color: #007bff; }
        .navbar-brand, .nav-link { color: #fff !important; }
        .hero-section { padding: 50px 0; background: url('hero-bg.jpg') center/cover no-repeat; color: white; text-align: center; }
        .login-card { margin-top: 20px; padding: 20px; border-radius: 10px; box-shadow: 0px 0px 10px rgba(0,0,0,0.1); }
        .footer { background-color: #343a40; color: white; padding: 10px; text-align: center; margin-top: 20px; }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand" href="index.php">Crowdfunding Platform</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="#about">About</a></li>
                
            </ul>
        </div>
    </div>
</nav>

<!-- Hero Section -->
<section class="hero-section">
    <div class="container">
        <h1>Welcome to Our Crowdfunding Platform</h1>
        <p>Empowering individuals and organizations to raise funds for meaningful causes.</p>
        <a href="" class="btn btn-light btn-lg">Explore Campaigns</a>
    </div>
</section>

<!-- Login Section -->
<div class="container">
    <div class="row mt-5">
        <!-- User Login -->
        <div class="col-md-6">
            <div class="card login-card">
                <h4 class="text-center">User Login</h4>
                <form action="user_login.php" method="POST">
                    <div class="mb-3">
                        <label>Email</label>
                        <input type="email" class="form-control" name="email" required>
                    </div>
                    <div class="mb-3">
                        <label>Password</label>
                        <input type="password" class="form-control" name="password" required>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Login</button>
                </form>
                <p class="text-center mt-2"><a href="user_register.php">New User? Register Here</a></p>
            </div>
        </div>

        <!-- Admin Login -->
        <div class="col-md-6">
            <div class="card login-card">
                <h4 class="text-center">Admin Login</h4>
                <form action="admin_login.php" method="POST">
                    <div class="mb-3">
                        <label>Admin Username</label>
                        <input type="text" class="form-control" name="admin_username" required>
                    </div>
                    <div class="mb-3">
                        <label>Password</label>
                        <input type="password" class="form-control" name="admin_password" required>
                    </div>
                    <button type="submit" class="btn btn-danger w-100">Admin Login</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- About Section -->
<section id="about" class="container mt-5">
    <h2 class="text-center">About Our Platform</h2>
    <p class="text-center">Our crowdfunding platform enables individuals and organizations to raise funds for their causes with transparency and efficiency.</p>
</section>

<!-- Footer -->
<div class="footer">
    &copy; <?php echo date("Y"); ?> Crowdfunding Platform. All Rights Reserved.
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
