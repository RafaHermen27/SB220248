<?php
session_start();
include 'config.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

// Handle User Actions (Approve, Block, Delete)
if (isset($_GET['action']) && isset($_GET['user_id'])) {
    $user_id = $_GET['user_id'];
    if ($_GET['action'] == "approve") {
        mysqli_query($conn, "UPDATE users SET status='approved' WHERE id=$user_id");
    } elseif ($_GET['action'] == "block") {
        mysqli_query($conn, "UPDATE users SET status='blocked' WHERE id=$user_id");
    } elseif ($_GET['action'] == "delete") {
        mysqli_query($conn, "DELETE FROM users WHERE id=$user_id");
    }
    header("Location: users.php");
    exit();
}

// Fetch Users Data
$users = mysqli_query($conn, "SELECT * FROM users");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users - Crowdfunding</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body { background-color: #f8f9fa; }
        .container { margin-top: 50px; }
        .card { padding: 20px; box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1); border-radius: 10px; }
        .navbar { background-color: #007bff; }
        .navbar-brand, .nav-link { color: #fff !important; }
        .status-approved { color: green; font-weight: bold; }
        .status-pending { color: orange; font-weight: bold; }
        .status-blocked { color: red; font-weight: bold; }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand" href="admin_dashboard.php">Crowdfunding Admin</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
            <li class="nav-item"><a class="nav-link" href="admin_dashboard.php">Dashboard</a></li>
                <li class="nav-item"><a class="nav-link" href="manage_campaigns.php">Manage Campaigns</a></li>
                <li class="nav-item"><a class="nav-link" href="users.php">Manage Users</a></li>
                <li class="nav-item"><a class="nav-link" href="transactions1.php">Transactions</a></li>
              
                <li class="nav-item"><a class="nav-link" href="index.php">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<!-- User Management Section -->
<div class="container">
    <h2 class="text-center">Manage Users</h2>
    <div class="table-responsive">
        <table class="table table-bordered table-striped mt-4">
            <thead class="table-primary">
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Status</th>
                    <th>Registered On</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($users)) { ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['name']; ?></td>
                    <td><?php echo $row['email']; ?></td>
                    <td>
                        <?php
                        if ($row['status'] == "approved") {
                            echo "<span class='status-approved'>Approved</span>";
                        } elseif ($row['status'] == "pending") {
                            echo "<span class='status-pending'>Pending</span>";
                        } else {
                            echo "<span class='status-blocked'>Blocked</span>";
                        }
                        ?>
                    </td>
                    <td><?php echo date("d-M-Y", strtotime($row['created_at'])); ?></td>
                    <td>
                        <?php if ($row['status'] == "pending") { ?>
                            <a href="?action=approve&user_id=<?php echo $row['id']; ?>" class="btn btn-success btn-sm">Approve</a>
                        <?php } ?>
                        <?php if ($row['status'] == "approved") { ?>
                            <a href="?action=block&user_id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">Block</a>
                        <?php } ?>
                        <a href="?action=delete&user_id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">Delete</a>
                    </td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
