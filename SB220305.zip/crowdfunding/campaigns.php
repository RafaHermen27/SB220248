<?php
session_start();
include 'config.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

// Handle Campaign Actions
if (isset($_GET['action']) && isset($_GET['campaign_id'])) {
    $campaign_id = $_GET['campaign_id'];
    if ($_GET['action'] == "approve") {
        mysqli_query($conn, "UPDATE campaigns SET status='approved' WHERE id=$campaign_id");
    } elseif ($_GET['action'] == "reject") {
        mysqli_query($conn, "UPDATE campaigns SET status='rejected' WHERE id=$campaign_id");
    } elseif ($_GET['action'] == "delete") {
        mysqli_query($conn, "DELETE FROM campaigns WHERE id=$campaign_id");
    }
    header("Location: campaigns.php");
    exit();
}

// Fetch Campaign Data
$campaigns = mysqli_query($conn, "SELECT * FROM campaigns");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Campaigns - Crowdfunding</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body { background-color: #f8f9fa; }
        .container { margin-top: 50px; }
        .card { padding: 20px; box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1); border-radius: 10px; }
        .navbar { background-color: #007bff; }
        .navbar-brand, .nav-link { color: #fff !important; }
        .status-approved { color: green; font-weight: bold; }
        .status-pending { color: orange; font-weight: bold; }
        .status-rejected { color: red; font-weight: bold; }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand" href="admin_dashboard.php">Crowdfunding Admin</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
            <li class="nav-item"><a class="nav-link active" href="dashboard.php">Dashboard</a></li>
                <li class="nav-item"><a class="nav-link" href="campaigns.php">Campaigns</a></li>
                <li class="nav-item"><a class="nav-link active" href="donate.php">Donation</a></li>
                <li class="nav-item"><a class="nav-link active" href="withdraw.php">withdraw</a></li>
            
              
                
                <li class="nav-item"><a class="nav-link" href="index.php">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<!-- Campaign Management Section -->
<div class="container">
    <h2 class="text-center">Manage Campaigns</h2>
    <div class="table-responsive">
        <table class="table table-bordered table-striped mt-4">
            <thead class="table-primary">
                <tr>
                    <th>ID</th>
                    <th>Title</th>
                    
                    <th>Goal Amount</th>
                    <th>Raised Amount</th>
                    <th>Status</th>
                    <th>Created On</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($campaigns)) { ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['title']; ?></td>
                    
                    <td>₹<?php echo number_format($row['goal_amount'], 2); ?></td>
                    <td>₹<?php echo number_format($row['raised_amount'], 2); ?></td>
                    <td>
                        <?php
                        if ($row['status'] == "approved") {
                            echo "<span class='status-approved'>Approved</span>";
                        } elseif ($row['status'] == "pending") {
                            echo "<span class='status-pending'>Pending</span>";
                        } else {
                            echo "<span class='status-rejected'>Rejected</span>";
                        }
                        ?>
                    </td>
                    <td><?php echo date("d-M-Y", strtotime($row['created_at'])); ?></td>
                    <td>
                        <?php if ($row['status'] == "pending") { ?>
                            <a href="?action=approve&campaign_id=<?php echo $row['id']; ?>" class="btn btn-success btn-sm">Approve</a>
                            <a href="?action=reject&campaign_id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">Reject</a>
                        <?php } ?>
                        <a href="?action=delete&campaign_id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">Delete</a>
                    </td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
