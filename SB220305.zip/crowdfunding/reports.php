<?php
session_start();
include 'config.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

// Fetch Data
$users = mysqli_query($conn, "SELECT * FROM users ORDER BY created_at DESC");
$transactions = mysqli_query($conn, "SELECT * FROM transactions ORDER BY created_at DESC");
$campaigns = mysqli_query($conn, "SELECT * FROM campaigns ORDER BY created_at DESC");

// Function to export CSV
if (isset($_POST['export_csv'])) {
    $type = $_POST['report_type'];
    $filename = $type . "_report_" . date("Y-m-d") . ".csv";
    header("Content-Type: text/csv");
    header("Content-Disposition: attachment; filename=\"$filename\"");
    $output = fopen("php://output", "w");
    
    if ($type == "users") {
        fputcsv($output, array('ID', 'Name', 'Email', 'Created At'));
        while ($row = mysqli_fetch_assoc($users)) {
            fputcsv($output, $row);
        }
    } elseif ($type == "transactions") {
        fputcsv($output, array('ID', 'User ID', 'Campaign ID', 'Amount', 'Status', 'Created At'));
        while ($row = mysqli_fetch_assoc($transactions)) {
            fputcsv($output, $row);
        }
    } elseif ($type == "campaigns") {
        fputcsv($output, array('ID', 'Title', 'Creator', 'Goal', 'Raised', 'Status', 'Created At'));
        while ($row = mysqli_fetch_assoc($campaigns)) {
            fputcsv($output, $row);
        }
    }
    
    fclose($output);
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports - Crowdfunding</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body { background-color: #f8f9fa; }
        .container { margin-top: 50px; }
        .card { padding: 20px; box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1); border-radius: 10px; }
        .navbar { background-color: #007bff; }
        .navbar-brand, .nav-link { color: #fff !important; }
        .table-responsive { max-height: 400px; overflow-y: scroll; }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand" href="admin_dashboard.php">Crowdfunding Admin</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
            <li class="nav-item"><a class="nav-link" href="admin_dashboard.php">Dashboard</a></li>
                <li class="nav-item"><a class="nav-link" href="manage_campaigns.php">Manage Campaigns</a></li>
                <li class="nav-item"><a class="nav-link" href="users.php">Manage Users</a></li>
                <li class="nav-item"><a class="nav-link" href="transactions1.php">Transactions</a></li>
                <li class="nav-item"><a class="nav-link" href="categories.php">Categories</a></li>
                <li class="nav-item"><a class="nav-link" href="reports.php">Reports</a></li>
             
                <li class="nav-item"><a class="nav-link" href="index.php">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<!-- Reports Section -->
<div class="container">
    <h2 class="text-center mb-4">Generate Reports</h2>

    <!-- Export CSV Form -->
    <div class="card mb-4">
        <h4 class="card-title text-center">Export Data</h4>
        <form method="POST">
            <div class="mb-3">
                <label class="form-label">Select Report Type</label>
                <select name="report_type" class="form-select" required>
                    <option value="users">Users</option>
                    <option value="transactions">Transactions</option>
                    <option value="campaigns">Campaigns</option>
                </select>
            </div>
            <button type="submit" name="export_csv" class="btn btn-primary w-100">Download CSV</button>
        </form>
    </div>

    <!-- Users Report -->
    <div class="card mb-4">
        <h4 class="card-title text-center">Users Report</h4>
        <div class="table-responsive">
            <table class="table table-bordered table-striped">
                <thead class="table-primary">
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Created At</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($users)) { ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo $row['name']; ?></td>
                        <td><?php echo $row['email']; ?></td>
                        <td><?php echo $row['created_at']; ?></td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Transactions Report -->
    <div class="card mb-4">
        <h4 class="card-title text-center">Transactions Report</h4>
        <div class="table-responsive">
            <table class="table table-bordered table-striped">
                <thead class="table-primary">
                    <tr>
                        <th>ID</th>
                        <th>User ID</th>
                        <th>Campaign ID</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Created At</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($transactions)) { ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo $row['user_id']; ?></td>
                        <td><?php echo $row['campaign_id']; ?></td>
                        <td><?php echo $row['amount']; ?></td>
                        <td><?php echo $row['status']; ?></td>
                        <td><?php echo $row['created_at']; ?></td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Campaigns Report -->
    <div class="card">
        <h4 class="card-title text-center">Campaigns Report</h4>
        <div class="table-responsive">
            <table class="table table-bordered table-striped">
                <thead class="table-primary">
                    <tr>
                        <th>ID</th>
                        <th>Title</th>
                        <th>Creator</th>
                        <th>Goal</th>
                        <th>Raised</th>
                        <th>Status</th>
                        <th>Created At</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($campaigns)) { ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo $row['title']; ?></td>
                        <td><?php echo $row['creator']; ?></td>
                        <td><?php echo $row['goal']; ?></td>
                        <td><?php echo $row['raised']; ?></td>
                        <td><?php echo $row['status']; ?></td>
                        <td><?php echo $row['created_at']; ?></td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
