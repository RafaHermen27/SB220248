<?php
session_start();
include 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: user_login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch all campaigns
$campaigns_query = "SELECT * FROM campaigns ORDER BY created_at DESC";
$campaigns_result = mysqli_query($conn, $campaigns_query);

// Handle donation submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['donate'])) {
    $campaign_id = mysqli_real_escape_string($conn, $_POST['campaign_id']);
    $amount = mysqli_real_escape_string($conn, $_POST['amount']);
    $message = mysqli_real_escape_string($conn, $_POST['message']);

    $donation_query = "INSERT INTO donations (user_id, campaign_id, amount, message, donated_at) 
                       VALUES ('$user_id', '$campaign_id', '$amount', '$message', NOW())";

    if (mysqli_query($conn, $donation_query)) {
        $success = "Donation made successfully!";
        header("Refresh:0");
    } else {
        $error = "Error making donation.";
    }
}

// Fetch all donations
$donations_query = "SELECT d.amount, d.message, d.donated_at, c.title 
                    FROM donations d 
                    JOIN campaigns c ON d.campaign_id = c.id 
                    WHERE d.user_id='$user_id' 
                    ORDER BY d.donated_at DESC";

$donations_result = mysqli_query($conn, $donations_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donate - Crowdfunding</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 50px;
        }
        .card {
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        .navbar {
            background-color: #007bff;
        }
        .navbar-brand, .nav-link {
            color: #fff !important;
        }
        .btn-primary {
            background-color: #28a745;
            border: none;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand" href="index.php">Crowdfunding</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
            <li class="nav-item"><a class="nav-link active" href="dashboard.php">Dashboard</a></li>
                <li class="nav-item"><a class="nav-link" href="campaigns.php">Campaigns</a></li>
                <li class="nav-item"><a class="nav-link active" href="donate.php">Donation</a></li>
                <li class="nav-item"><a class="nav-link active" href="withdraw.php">withdraw</a></li>
               
              
                
                <li class="nav-item"><a class="nav-link" href="index.php">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<!-- Donation Form -->
<div class="container">
    <h3 class="text-center">Make a Donation</h3>

    <?php if (isset($success)) { echo "<div class='alert alert-success'>$success</div>"; } ?>
    <?php if (isset($error)) { echo "<div class='alert alert-danger'>$error</div>"; } ?>

    <div class="card p-4">
        <h5>Donate to a Campaign</h5>
        <form method="POST">
            <div class="mb-3">
                <label class="form-label">Select Campaign</label>
                <select name="campaign_id" class="form-control" required>
                    <option value="">-- Select a Campaign --</option>
                    <?php while ($campaign = mysqli_fetch_assoc($campaigns_result)) { ?>
                        <option value="<?php echo $campaign['id']; ?>"><?php echo htmlspecialchars($campaign['title']); ?></option>
                    <?php } ?>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Amount (₹)</label>
                <input type="number" name="amount" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Message (Optional)</label>
                <textarea name="message" class="form-control"></textarea>
            </div>
            <button type="submit" name="donate" class="btn btn-primary w-100">Donate Now</button>
        </form>
    </div>

    <!-- Donation History -->
    <h4 class="mt-4">Your Past Donations</h4>
    <div class="row">
        <?php while ($donation = mysqli_fetch_assoc($donations_result)) { ?>
            <div class="col-md-6">
                <div class="card p-3 mt-3">
                    <h5>Donated to: <?php echo htmlspecialchars($donation['title']); ?></h5>
                    <p><strong>Amount:</strong> ₹<?php echo number_format($donation['amount']); ?></p>
                    <p><strong>Message:</strong> <?php echo nl2br(htmlspecialchars($donation['message'])); ?></p>
                    <p><small>Donated on: <?php echo date("F j, Y", strtotime($donation['donated_at'])); ?></small></p>
                </div>
            </div>
        <?php } ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
