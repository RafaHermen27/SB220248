<?php
session_start();
include 'config.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

// Handle logout
if (isset($_GET['logout'])) {
    session_unset();
    session_destroy();
    header("Location: admin_login.php");
    exit();
}

// Fetch statistics with prepared statements
$total_campaigns = 0;
$total_users = 0;
$total_funds = 0;

try {
    // Total Campaigns
    $stmt = mysqli_prepare($conn, "SELECT COUNT(*) AS total FROM campaigns");
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    if ($row = mysqli_fetch_assoc($result)) {
        $total_campaigns = $row['total'];
    }

    // Total Users
    $stmt = mysqli_prepare($conn, "SELECT COUNT(*) AS total FROM users");
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    if ($row = mysqli_fetch_assoc($result)) {
        $total_users = $row['total'];
    }

    // Total Funds
    $stmt = mysqli_prepare($conn, "SELECT SUM(amount) AS total FROM donations");
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    if ($row = mysqli_fetch_assoc($result)) {
        $total_funds = $row['total'] ?? 0; // Default to 0 if NULL
    }
} catch (Exception $e) {
    // Log error or display a generic message
    echo "An error occurred while fetching dashboard data.";
    // For debugging: echo "Error: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Crowdfunding</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .dashboard-container {
            margin-top: 50px;
        }
        .card {
            padding: 20px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }
        .navbar {
            background-color: #007bff;
        }
        .navbar-brand, .nav-link {
            color: #fff !important;
        }
        .dashboard-title {
            font-size: 24px;
            font-weight: bold;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand" href="admin_dashboard.php">Crowdfunding Admin</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="admin_dashboard.php">Dashboard</a></li>
                <li class="nav-item"><a class="nav-link" href="manage_campaigns.php">Manage Campaigns</a></li>
                <li class="nav-item"><a class="nav-link" href="manage_users.php">Manage Users</a></li>
                <li class="nav-item"><a class="nav-link" href="view_donate.php">View Donations</a></li>
                <li class="nav-item"><a class="nav-link" href="admin_withdrawals.php">View Withdrawals</a></li>
                <li class="nav-item"><a class="nav-link" href="index.php">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<!-- Dashboard Content -->
<div class="container dashboard-container">
    <h2 class="text-center dashboard-title">Admin Dashboard</h2>
    
    <div class="row mt-4">
        <div class="col-md-4">
            <div class="card bg-primary text-white text-center">
                <h4>Total Campaigns</h4>
                <h2><?php echo $total_campaigns; ?></h2>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card bg-success text-white text-center">
                <h4>Total Users</h4>
                <h2><?php echo $total_users; ?></h2>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card bg-warning text-white text-center">
                <h4>Total Funds Raised</h4>
                <h2>₹<?php echo number_format($total_funds, 2); ?></h2>
            </div>
        </div>
    </div>

    <div class="text-center mt-4">
        <a href="manage_campaigns.php" class="btn btn-primary">Manage Campaigns</a>
        <a href="manage_users.php" class="btn btn-success">Manage Users</a>
        <a href="view_donations.php" class="btn btn-warning">View Transactions</a>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>