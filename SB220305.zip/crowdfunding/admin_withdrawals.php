<?php
session_start();
include 'config.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

// Handle status update
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_status'])) {
    $withdrawal_id = $_POST['withdrawal_id'];
    $status = $_POST['status'];

    $update_query = "UPDATE withdrawals SET status='$status' WHERE id='$withdrawal_id'";
    if (mysqli_query($conn, $update_query)) {
        $success = "Withdrawal request updated successfully!";
    } else {
        $error = "Error updating withdrawal status.";
    }
}

// Fetch all withdrawal requests
$withdrawals_query = "SELECT * FROM withdrawals ORDER BY requested_at DESC";
$withdrawals_result = mysqli_query($conn, $withdrawals_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Withdrawals</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body { background-color: #f8f9fa; }
        .container { margin-top: 50px; }
        .card { box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1); }
        .navbar { background-color: #343a40; }
        .navbar-brand, .nav-link { color: #fff !important; }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand" href="admin_dashboard.php">Admin Panel</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="admin_dashboard.php">Dashboard</a></li>
                <li class="nav-item"><a class="nav-link active" href="admin_withdrawals.php">Withdrawals</a></li>
                <li class="nav-item"><a class="nav-link" href="index.php">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<!-- Withdrawal Requests -->
<div class="container">
    <h3 class="text-center">Manage Withdrawals</h3>

    <?php if (isset($success)) { echo "<div class='alert alert-success'>$success</div>"; } ?>
    <?php if (isset($error)) { echo "<div class='alert alert-danger'>$error</div>"; } ?>

    <table class="table table-bordered mt-4">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Campaign Title</th>
                <th>Requested By</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Requested At</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($withdrawal = mysqli_fetch_assoc($withdrawals_result)) { ?>
            <tr>
                <td><?php echo $withdrawal['id']; ?></td>
                <td><?php echo htmlspecialchars($withdrawal['campaign_title']); ?></td>
                <td><?php echo htmlspecialchars($withdrawal['requested_by']); ?></td>
                <td>₹<?php echo number_format($withdrawal['amount'], 2); ?></td>
                <td><span class="badge bg-<?php echo ($withdrawal['status'] == 'approved') ? 'success' : (($withdrawal['status'] == 'rejected') ? 'danger' : 'warning'); ?>">
                    <?php echo ucfirst($withdrawal['status']); ?>
                </span></td>
                <td><?php echo date("F j, Y, g:i a", strtotime($withdrawal['requested_at'])); ?></td>
                <td>
                    <form method="POST" class="d-inline">
                        <input type="hidden" name="withdrawal_id" value="<?php echo $withdrawal['id']; ?>">
                        <select name="status" class="form-select d-inline w-auto">
                            <option value="pending" <?php echo ($withdrawal['status'] == 'pending') ? 'selected' : ''; ?>>Pending</option>
                            <option value="approved" <?php echo ($withdrawal['status'] == 'approved') ? 'selected' : ''; ?>>Approved</option>
                            <option value="rejected" <?php echo ($withdrawal['status'] == 'rejected') ? 'selected' : ''; ?>>Rejected</option>
                        </select>
                        <button type="submit" name="update_status" class="btn btn-sm btn-primary">Update</button>
                    </form>
                </td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
