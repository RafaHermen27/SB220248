<?php
$host = "localhost"; // Your database host
$user = "root"; // Database username (default for XAMPP)
$password = ""; // Database password (default is empty in XAMPP)
$database = "crowdfunding_db"; // Your database name

// Create connection
$conn = mysqli_connect($host, $user, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
