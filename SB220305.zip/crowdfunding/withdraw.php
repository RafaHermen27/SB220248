<?php
session_start();
include 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: user_login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Handle withdrawal request submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['request_withdrawal'])) {
    $campaign_title = mysqli_real_escape_string($conn, $_POST['campaign_title']);
    $amount = mysqli_real_escape_string($conn, $_POST['amount']);

    $withdraw_query = "INSERT INTO withdrawals (campaign_title, requested_by, amount, status, requested_at) 
                        VALUES ('$campaign_title', '$user_id', '$amount', 'pending', NOW())";

    if (mysqli_query($conn, $withdraw_query)) {
        $success = "Withdrawal request submitted successfully!";
    } else {
        $error = "Error submitting withdrawal request.";
    }
}

// Fetch all withdrawal requests for the logged-in user
$withdrawals_query = "SELECT * FROM withdrawals WHERE requested_by='$user_id' ORDER BY requested_at DESC";
$withdrawals_result = mysqli_query($conn, $withdrawals_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Withdraw - Crowdfunding</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body { background-color: #f8f9fa; }
        .container { margin-top: 50px; }
        .card { box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1); }
        .navbar { background-color: #007bff; }
        .navbar-brand, .nav-link { color: #fff !important; }
        .btn-primary { background-color: #28a745; border: none; }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand" href="index.php">Crowdfunding</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
                <li class="nav-item"><a class="nav-link" href="campaigns.php">Campaigns</a></li>
                <li class="nav-item"><a class="nav-link" href="donate.php">Donate</a></li>
                <li class="nav-item"><a class="nav-link active" href="withdraw.php">Withdraw</a></li>
                <li class="nav-item"><a class="nav-link" href="index.php">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<!-- Withdrawal Form -->
<div class="container">
    <h3 class="text-center">Request Withdrawal</h3>

    <?php if (isset($success)) { echo "<div class='alert alert-success'>$success</div>"; } ?>
    <?php if (isset($error)) { echo "<div class='alert alert-danger'>$error</div>"; } ?>

    <div class="card p-4">
        <h5>Withdraw Funds</h5>
        <form method="POST">
            <div class="mb-3">
                <label class="form-label">Campaign Title</label>
                <input type="text" name="campaign_title" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Amount (₹)</label>
                <input type="number" name="amount" class="form-control" required>
            </div>
            <button type="submit" name="request_withdrawal" class="btn btn-primary w-100">Request Withdrawal</button>
        </form>
    </div>

    <!-- Withdrawal History -->
    <h4 class="mt-4">Your Withdrawal Requests</h4>
    <div class="row">
        <?php while ($withdrawal = mysqli_fetch_assoc($withdrawals_result)) { ?>
            <div class="col-md-6">
                <div class="card p-3 mt-3">
                    <h5>Campaign: <?php echo htmlspecialchars($withdrawal['campaign_title']); ?></h5>
                    <p><strong>Amount:</strong> ₹<?php echo number_format($withdrawal['amount'], 2); ?></p>
                    <p><strong>Status:</strong> <span class="badge bg-<?php echo ($withdrawal['status'] == 'approved') ? 'success' : (($withdrawal['status'] == 'rejected') ? 'danger' : 'warning'); ?>"> 
                        <?php echo ucfirst($withdrawal['status']); ?>
                    </span></p>
                    <p><small>Requested on: <?php echo date("F j, Y, g:i a", strtotime($withdrawal['requested_at'])); ?></small></p>
                </div>
            </div>
        <?php } ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
