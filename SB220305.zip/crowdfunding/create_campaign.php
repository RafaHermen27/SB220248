<?php
session_start();
include 'config.php';

// Check if user is logged in (Assuming users have sessions)
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id']; // Get logged-in user ID
$error = "";
$success = "";

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $goal_amount = floatval($_POST['goal_amount']);

    if (empty($title) || empty($description) || $goal_amount <= 0) {
        $error = "All fields are required, and goal amount must be greater than zero.";
    } else {
        // ✅ Add user_id to the INSERT query
        $query = "INSERT INTO campaigns (user_id, title, description, goal_amount, status) 
                  VALUES ('$user_id', '$title', '$description', '$goal_amount', 'pending')";

        if (mysqli_query($conn, $query)) {
            $success = "Campaign submitted successfully! Awaiting admin approval.";
        } else {
            $error = "Error: " . mysqli_error($conn);
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Campaign</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand" href="index.php">Crowdfunding</a>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
                <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <h3 class="mb-3">Create a New Campaign</h3>

    <?php if (!empty($error)) { ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php } ?>
    
    <?php if (!empty($success)) { ?>
        <div class="alert alert-success"><?php echo $success; ?></div>
    <?php } ?>

    <form action="" method="POST">
        <div class="mb-3">
            <label>Campaign Title</label>
            <input type="text" name="title" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Campaign Description</label>
            <textarea name="description" class="form-control" rows="4" required></textarea>
        </div>
        <div class="mb-3">
            <label>Goal Amount (₹)</label>
            <input type="number" name="goal_amount" class="form-control" step="0.01" required>
        </div>
        <button type="submit" class="btn btn-primary w-100">Submit Campaign</button>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
