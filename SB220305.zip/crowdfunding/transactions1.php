<?php
session_start();
include 'config.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

// Handle Withdrawal Approvals
if (isset($_GET['action']) && isset($_GET['withdrawal_id'])) {
    $withdrawal_id = $_GET['withdrawal_id'];
    if ($_GET['action'] == "approve") {
        mysqli_query($conn, "UPDATE withdrawals SET status='approved' WHERE id=$withdrawal_id");
    } elseif ($_GET['action'] == "reject") {
        mysqli_query($conn, "UPDATE withdrawals SET status='rejected' WHERE id=$withdrawal_id");
    }
    header("Location: transactions.php");
    exit();
}

// Fetch Donations with JOINs
$donations = mysqli_query($conn, "
    SELECT donations.id, donations.amount, donations.donated_at, 
           users.name AS donor_name, 
           campaigns.title AS campaign_title
    FROM donations
    JOIN users ON donations.user_id = users.id
    JOIN campaigns ON donations.campaign_id = campaigns.id
    ORDER BY donations.donated_at DESC
");

// Fetch Withdrawals
$withdrawals = mysqli_query($conn, "SELECT * FROM withdrawals ORDER BY requested_at DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Transactions - Crowdfunding</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body { background-color: #f8f9fa; }
        .container { margin-top: 50px; }
        .card { padding: 20px; box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1); border-radius: 10px; }
        .navbar { background-color: #007bff; }
        .navbar-brand, .nav-link { color: #fff !important; }
        .status-approved { color: green; font-weight: bold; }
        .status-pending { color: orange; font-weight: bold; }
        .status-rejected { color: red; font-weight: bold; }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand" href="admin_dashboard.php">Crowdfunding Admin</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="admin_dashboard.php">Dashboard</a></li>
                <li class="nav-item"><a class="nav-link" href="manage_campaigns.php">Manage Campaigns</a></li>
                <li class="nav-item"><a class="nav-link" href="users.php">Manage Users</a></li>
                <li class="nav-item"><a class="nav-link" href="transactions.php">Transactions</a></li>
                <li class="nav-item"><a class="nav-link" href="index.php">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<!-- Transactions Section -->
<div class="container">
    <h2 class="text-center mb-4">Manage Transactions</h2>

    <!-- Donations Table -->
    <div class="card mb-4">
        <h4 class="card-title text-center">Donation Transactions</h4>
        <div class="table-responsive">
            <table class="table table-bordered table-striped">
                <thead class="table-primary">
                    <tr>
                        <th>ID</th>
                        <th>Donor</th>
                        <th>Campaign</th>
                        <th>Amount</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($donations)) { ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo htmlspecialchars($row['donor_name']); ?></td>
                        <td><?php echo htmlspecialchars($row['campaign_title']); ?></td>
                        <td>₹<?php echo number_format($row['amount'], 2); ?></td>
                        <td><?php echo date("d-M-Y", strtotime($row['donated_at'])); ?></td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Withdrawals Table -->
    <div class="card">
        <h4 class="card-title text-center">Withdrawal Requests</h4>
        <div class="table-responsive">
            <table class="table table-bordered table-striped">
                <thead class="table-danger">
                    <tr>
                        <th>ID</th>
                        <th>Campaign</th>
                        <th>Requested By</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Requested On</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($withdrawals)) { ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo htmlspecialchars($row['campaign_title']); ?></td>
                        <td><?php echo htmlspecialchars($row['requested_by']); ?></td>
                        <td>₹<?php echo number_format($row['amount'], 2); ?></td>
                        <td>
                            <?php
                            if ($row['status'] == "approved") {
                                echo "<span class='status-approved'>Approved</span>";
                            } elseif ($row['status'] == "pending") {
                                echo "<span class='status-pending'>Pending</span>";
                            } else {
                                echo "<span class='status-rejected'>Rejected</span>";
                            }
                            ?>
                        </td>
                        <td><?php echo date("d-M-Y", strtotime($row['requested_at'])); ?></td>
                        <td>
                            <?php if ($row['status'] == "pending") { ?>
                                <a href="?action=approve&withdrawal_id=<?php echo $row['id']; ?>" class="btn btn-success btn-sm">Approve</a>
                                <a href="?action=reject&withdrawal_id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm">Reject</a>
                            <?php } else { ?>
                                <button class="btn btn-secondary btn-sm" disabled>Processed</button>
                            <?php } ?>
                        </td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
