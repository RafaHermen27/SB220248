<?php
session_start();
include 'config.php';

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: view_donate.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch all donations with campaign details
$donations_query = "SELECT d.id, d.amount, d.message, d.donated_at, c.title, u.name AS donor_name
                    FROM donations d
                    JOIN campaigns c ON d.campaign_id = c.id
                    JOIN users u ON d.user_id = u.id
                    ORDER BY d.donated_at DESC";
$donations_result = mysqli_query($conn, $donations_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Donations - Crowdfunding</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 50px;
        }
        .card {
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        .navbar {
            background-color: #007bff;
        }
        .navbar-brand, .nav-link {
            color: #fff !important;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand" href="index.php">Crowdfunding</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="admin_dashboard.php">Dashboard</a></li>
                <li class="nav-item"><a class="nav-link" href="campaigns.php">Campaigns</a></li>
                <li class="nav-item"><a class="nav-link active" href="view_donate.php">View Donations</a></li>
                <li class="nav-item"><a class="nav-link" href="index.php">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<!-- Donations List -->
<div class="container">
    <h3 class="text-center">All Donations</h3>
    <div class="card p-4">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Donor</th>
                    <th>Campaign</th>
                    <th>Amount (₹)</th>
                   
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php if (mysqli_num_rows($donations_result) > 0) {
                    $count = 1;
                    while ($donation = mysqli_fetch_assoc($donations_result)) { ?>
                        <tr>
                            <td><?php echo $count++; ?></td>
                            <td><?php echo htmlspecialchars($donation['donor_name']); ?></td>
                            <td><?php echo htmlspecialchars($donation['title']); ?></td>
                            <td>₹<?php echo number_format($donation['amount'], 2); ?></td>
                           
                            <td><?php echo date("F j, Y", strtotime($donation['donated_at'])); ?></td>
                        </tr>
                    <?php } 
                } else { ?>
                    <tr>
                        <td colspan="6" class="text-center">No donations found.</td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
